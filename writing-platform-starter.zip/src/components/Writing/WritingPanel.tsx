const WritingPanel = () => <div>📝 Writing Panel Placeholder</div>;
export default WritingPanel;
